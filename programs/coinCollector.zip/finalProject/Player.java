import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Stack;

public class Player implements Serializable {
	
	private Color color;
	private int x, y;
	private Stack<Integer> health = new Stack<Integer>();
	private ArrayList<Bomb> bombs = new ArrayList<Bomb>();
	private Bomb placed = null;
	private boolean moved = false;
	
	public Player(Color color, int x, int y) {
		this.color = color;
		this.x = x;
		this.y = y;
		
		for(int i=0; i<5; i++) {
			health.push(1);
		}
		
		for(int i=0; i<5; i++) {
			bombs.add(new Bomb());
		}
	}
	
	public void draw(Graphics g, int x, int y) {
		
		Graphics2D g2 = (Graphics2D) g;
	    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		
		g2.setColor(color);
		g2.fillOval(x, y, 20, 20);
		g2.fillRect(x, y+20, 20, 20);
		
	}
	
	public Location getLocation() {
		return new Location(x, y);
	}
	
	public void setLocation(Location loc) {
		x = loc.getX();
		y = loc.getY();
	}
	
	public Stack<Integer> getHealth() {
		return health;
	}
	
	public void hit() {
		health.pop();
		x = 6;
		y = 6;
	}
	
	public void moved() {
		moved = true;
	}
	
	public boolean getMoved() {
		return moved;
	}
	
	public String getPlayer() {
		if(color.equals(Color.red)) return "p1"; // does this work
		else return "p2";
	}
	
	public Bomb placeBomb(Location loc) {
		bombs.get(bombs.size()-1).place(loc);
		Bomb b = bombs.remove(bombs.size()-1);
		placed = b;
		return b;
	}
	
	public ArrayList<Bomb> getBombs() {
		return bombs;
	}
	
	public Bomb getPlaced() {
		return placed;
	}
	
	public void reset() {
		for(int i=0; i<5-bombs.size(); i++) {
			bombs.add(new Bomb());
		}
		for(int i=0; i<5-health.size(); i++) {
			health.push(1);
		}
		moved = false;
	}

}

import java.io.Serializable;

public class Location implements Serializable{
	
	private int x, y;
	
	public Location(int x, int y) {
		this.x = x;
		this.y = y;
	}
	
	public int getX() {
		return x;
	}
	
	public int getY() {
		return y;
	}
	
	public boolean equals(Object obj) {
		Location l = (Location) obj;
		if(l.getX()==x && l.getY()==y) return true;
		return false;
	}
	
	public int hashCode() {
		return (x * 12 + y * 19)/2;
	}

}

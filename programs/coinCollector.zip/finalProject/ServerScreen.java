import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.border.LineBorder;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.Stack;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;

public class ServerScreen extends JPanel implements KeyListener, ActionListener{
	
	private ObjectOutputStream out;
	private Game game;
	private int gridSize = 13;
	private int startPosX = 6, startPosY = 6;
	private Square[][] grid = new Square[gridSize][gridSize];
	private Map<Location, Object> gameMap = new HashMap<Location, Object>();
	private ArrayList<Item> collectedOne = new ArrayList<Item>(), collectedTwo = new ArrayList<Item>();
	private Player p1 = new Player(Color.red, 6, 6), p2;
	private JLabel scoreOne, scoreTwo, winner, countDown;
	private JButton showInstructions, reset;
	private JTextArea instructions;
	private int p1Score = 0, p2Score = 0;
	private boolean connected = false, gameActive = true;
	private BufferedImage bomb, spike, coin, confetti;
	private Image icon;
	
	public ServerScreen() {

		this.setLayout(null);
		this.addKeyListener(this);
		
		playSound("bgMusic");

		try {
			icon = new ImageIcon("loading.gif").getImage();
			bomb = ImageIO.read(new File("bomb.png"));
			spike = ImageIO.read(new File("spike.png"));
			coin = ImageIO.read(new File("coin.png"));
			confetti = ImageIO.read(new File("confetti.gif"));
		} catch (IOException e) {
            e.printStackTrace();
        }
		
    	Location loc;
    	for(int i=0; i<13; i++) {
    		loc = new Location((int)(Math.random()*13), (int)(Math.random()*13));
    		if(!gameMap.containsKey(loc) && (loc.getX()!=startPosX && loc.getY()!=startPosY)) {
    			gameMap.put(loc, new Item(loc.getX(), loc.getY()));
    		} else {
    			i--;
    		}
    	}
    	
    	for(int i=0; i<10; i++) {
    		loc = new Location((int)(Math.random()*13), (int)(Math.random()*13));
    		if(!gameMap.containsKey(loc) && (loc.getX()!=startPosX && loc.getY()!=startPosY)) {
    			gameMap.put(loc, new Spike(loc.getX(), loc.getY()));
    		} else {
    			i--;
    		}
    	}
    	
    	reset = new JButton("Replay");
    	reset.setBounds(500, 350, 150, 50);
    	reset.setFont(new Font("Helvetica", Font.PLAIN, 30));
    	reset.addActionListener(this);
    	reset.setVisible(false);
    	this.add(reset);
    	
    	showInstructions = new JButton("Show Instructions");
    	showInstructions.setBounds(515, 715, 120, 20);
    	showInstructions.setFont(new Font("Helvetica", Font.PLAIN, 10));
    	showInstructions.addActionListener(this);
    	this.add(showInstructions);
    	
    	instructions = new JTextArea();
    	instructions.setBounds(387, 200, 375, 90);
    	instructions.setText("Arrow buttons to move\nSpace to place bomb\nGet as many coins as possible!");
    	instructions.setFont(new Font("Helvetica", Font.PLAIN, 25));
    	instructions.setEditable(false);
    	instructions.setBorder(new LineBorder(Color.yellow, 5, true));
    	
    	scoreOne = new JLabel("Score: " + p1Score);
    	scoreOne.setFont(new Font("Helvetica", Font.BOLD, 40));
    	scoreOne.setForeground(new Color(255, 136, 128));
    	scoreOne.setBounds(30, 70, 200, 60);
    	this.add(scoreOne);
    	
    	scoreTwo = new JLabel("Score: " + p2Score);
    	scoreTwo.setFont(new Font("Helvetica", Font.BOLD, 40));
    	scoreTwo.setForeground(new Color(77, 148, 255));
    	scoreTwo.setBounds(940, 70, 200, 60);
    	this.add(scoreTwo);
    	
    	winner = new JLabel();
    	winner.setFont(new Font("Helvetica", Font.BOLD, 90));
    	winner.setBounds(400, 200, 400, 100);
    	this.add(winner);

    	countDown = new JLabel();
    	countDown.setFont(new Font("Helvetica", Font.BOLD, 60));
    	countDown.setBounds(400, 200, 200, 60);
    	this.add(countDown);
    	
    	game = new Game(gameMap, p1);
    	
    	this.setFocusable(true);
    	this.requestFocusInWindow();
    	
	}

    public Dimension getPreferredSize() {
        return new Dimension(1150, 750);
    }
    
    public void paintComponent(Graphics g) {
    	super.paintComponent(g);
    	
    	g.setColor(Color.red);
    	g.fillRect(0, 0, this.getWidth()/2, this.getHeight());
    	g.setColor(Color.blue);
    	g.fillRect(this.getWidth()/2, 0, this.getWidth()/2, this.getHeight());
    	
    	// Draw grid
    	
    	g.setColor(Color.black);
    	
    	for(int r=0; r<gridSize; r++) {
    		for(int c=0; c<gridSize; c++) {
    			grid[r][c] = new Square(250 + c*50, 50 + r*50);
    			grid[r][c].draw(g);
    		}
    	}
    	
    	// Draw items and spikes
    	
    	Object[] items = gameMap.values().toArray();
		for(Object each : items) {
    		if(each instanceof Item) {
    			Item i = (Item) each;
    			grid[i.getLocation().getY()][i.getLocation().getX()].drawItem(i, g, coin);
    		} else if(each instanceof Spike) {
    			Spike s = (Spike) each;
    			grid[s.getLocation().getY()][s.getLocation().getX()].drawSpike(s, g, spike);
    		} else if(each instanceof Bomb) {
    			Bomb b = (Bomb) each;
    			grid[b.getLocation().getY()][b.getLocation().getX()].drawBomb(b, g, bomb);
    		}
    		
    	}
    	
    	// Draw player
    	
		grid[p1.getLocation().getY()][p1.getLocation().getX()].drawPlayer(p1, g, "p1");
		if(connected) grid[p2.getLocation().getY()][p2.getLocation().getX()].drawPlayer(p2, g, "p2");
		
		// Draw collected
		int c = 0, r = 0;
		for(int i=0; i<collectedOne.size(); i++) {
			if(i%5==0) {
				r++;
				c=0;
			}
			collectedOne.get(i).draw(g, scoreOne.getX()+7+c*30, 150+r*30, coin);
			c++;
		}
		
		c = 0;
		r = 0;
		for(int i=0; i<collectedTwo.size(); i++) {
			if(i%5==0) {
				r++;
				c=0;
			}
			collectedTwo.get(i).draw(g, scoreTwo.getX()+7+c*30, 150+r*30, coin);
			c++;
		}
		
		// Health bars
		Stack<Integer> health1 = p1.getHealth();
		if(health1.size()<=2) g.setColor(Color.red);
		else if(health1.size()<=4) g.setColor(Color.yellow);
		else g.setColor(Color.green);
		for(int i=0; i<health1.size(); i++) {
			g.fillRect(30+i*32, 30, 30, 40);
		}
		
		if(connected) {
			Stack<Integer> health2 = p2.getHealth();
			if(health2.size()<=2) g.setColor(Color.red);
			else if(health2.size()<=4) g.setColor(Color.yellow);
			else g.setColor(Color.green);
			for(int i=0; i<health2.size(); i++) {
				g.fillRect(scoreTwo.getX()+i*32, 30, 30, 40);
			}
		}
		
		// draw bombs
		
		ArrayList<Bomb> bombs = p1.getBombs();
		for(int i=0; i<bombs.size(); i++) {
			bombs.get(i).draw(g, scoreOne.getX()+5+i*30, 130, bomb);
		}
		
		if(connected) {
			bombs = p2.getBombs();
			for(int i=0; i<bombs.size(); i++) {
				bombs.get(i).draw(g, scoreTwo.getX()+5+i*30, 130, bomb);
			}
		}
		
		// draw loading
		
		if(!connected) {
			g.drawImage(icon, 495, 290, this);
		}
    	
		// draw confetti
		
		if(winner.getText().equals("You win!")) g.drawImage(confetti, 0, 0, this);

    }
    
    public void poll() throws IOException {
        int portNumber = 1024;
         
        ServerSocket serverSocket = new ServerSocket(portNumber);
        Socket clientSocket = serverSocket.accept();
        out = new ObjectOutputStream(clientSocket.getOutputStream());
        ObjectInputStream ino = new ObjectInputStream(clientSocket.getInputStream());
        PushbackInputStream pin = new PushbackInputStream(clientSocket.getInputStream());

        out.writeObject(game);
        
        while(true) {
        	try {
        		if(pin.available()!=0) {
        			p2 = (Player) ino.readObject();
        			connected = true;
        			encountered(p2);
        			if(p2.getPlaced()!=null && !gameMap.containsKey(p2.getPlaced().getLocation())) {
        				gameMap.put(p2.getPlaced().getLocation(), p2.getPlaced());
        			}
        			checkWinner();
        			repaint();
        		}
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
        }
     
    }

	public void keyPressed(KeyEvent e) {
		if(gameActive && connected) {
			int keyCode = e.getKeyCode();
			
			if(keyCode==KeyEvent.VK_UP) {
				if(p1.getLocation().getY()>0) {
					p1.setLocation(new Location(p1.getLocation().getX(), p1.getLocation().getY()-1));
					try {
						checkMovement();
					} catch (IOException e1) {
						e1.printStackTrace();
					}
				}
			} else if(keyCode==KeyEvent.VK_DOWN) {
				if(p1.getLocation().getY()<gridSize-1) {
					p1.setLocation(new Location(p1.getLocation().getX(), p1.getLocation().getY()+1));
					try {
						checkMovement();
					} catch (IOException e1) {
						e1.printStackTrace();
					}
				}
			} else if(keyCode==KeyEvent.VK_RIGHT) {
				if(p1.getLocation().getX()<gridSize-1) {
					p1.setLocation(new Location(p1.getLocation().getX()+1, p1.getLocation().getY()));
					try {
						checkMovement();
					} catch (IOException e1) {
						e1.printStackTrace();
					}
				}
			} else if(keyCode==KeyEvent.VK_LEFT) {
				if(p1.getLocation().getX()>0) {
					p1.setLocation(new Location(p1.getLocation().getX()-1, p1.getLocation().getY()));
					try {
						checkMovement();
					} catch (IOException e1) {
						e1.printStackTrace();
					}
				}
			} else if(keyCode==KeyEvent.VK_SPACE) {
				if(!p1.getBombs().isEmpty()) {
					gameMap.put(p1.getLocation(), p1.placeBomb(p1.getLocation()));
				}
				repaint();
			}
		}
	}
	
	public void checkMovement() throws IOException {
		p1.moved();
		out.reset();
		out.writeObject(game); 
		encountered(p1);
		repaint();
	}

	public void keyReleased(KeyEvent e) {}
	public void keyTyped(KeyEvent e) {}
	
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==showInstructions) {
			if(instructions.getParent()!=this) {
				this.add(instructions);
			} else {
				this.remove(instructions);
			}
		} else if(e.getSource()==reset) {
			try {
				setUp();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			reset.setVisible(false);
		}
    	this.requestFocusInWindow();
	}
	
	public void encountered(Player p) {
		if(gameMap.containsKey(p.getLocation())) {
			if(gameMap.get(p.getLocation()) instanceof Item) {
				playSound("collect");
				if(p.getPlayer().equals("p1")) {
					scoreOne.setText("Score: " + ++p1Score);
					collectedOne.add((Item) gameMap.remove(p.getLocation()));
				}else {
					scoreTwo.setText("Score: " + ++p2Score);
					collectedTwo.add((Item) gameMap.remove(p.getLocation()));
				}
			} else if(gameMap.get(p.getLocation()) instanceof Spike || gameMap.get(p.getLocation()) instanceof Bomb) {
				gameMap.remove(p.getLocation());
				p.hit();
				playSound("health");
			}
			checkWinner();
			repaint();
		}
	}
	
	public void checkWinner() {
		// checking health
		if(p1.getHealth().size()==0) {
			winner.setForeground(Color.red);
			winner.setText("You lose");
			gameActive = false;
			reset.setVisible(true);
		} else if(p2.getHealth().size()==0) {
			winner.setForeground(Color.green);
			winner.setText("You win");
			gameActive = false;
			reset.setVisible(true);
		}
		
		// checking collected
		for(Object each : gameMap.values()) {
			if(each instanceof Item) {
				return;
			}
		}
		if(p1Score>p2Score) {
			winner.setForeground(Color.green);
			winner.setText("You win!");
			reset.setVisible(true);
		} else {
			winner.setForeground(Color.red);
			winner.setText("You lose");
			reset.setVisible(true);
		}
		gameActive = false;
	}
	
	public void playSound(String name) {
    	try {
    		URL url;
    		if(name.equals("collect")) {
                url = this.getClass().getClassLoader().getResource("collect.wav");
    		} else if(name.equals("bgMusic")) {
    			url = this.getClass().getClassLoader().getResource("bgMusic.wav");
    		} else {
    			url = this.getClass().getClassLoader().getResource("healthloss.wav");
    		} 
            Clip clip = AudioSystem.getClip();
            clip.open(AudioSystem.getAudioInputStream(url));
            if(name.equals("bgMusic")) clip.loop(clip.LOOP_CONTINUOUSLY);
            else clip.start();
        } catch (Exception exc) {
           exc.printStackTrace(System.out);
        }
    }
	
	public void setUp() throws IOException {
		gameActive = true;
		gameMap.clear();
		p1Score = 0;
		p2Score = 0;
		p1.setLocation(new Location(6, 6));
		p2.setLocation(new Location(6, 6));
		p1.reset();
		p2.reset();
		winner.setText("");
		collectedOne.clear();
		collectedTwo.clear();
		
		Location loc;
    	for(int i=0; i<13; i++) {
    		loc = new Location((int)(Math.random()*13), (int)(Math.random()*13));
    		if(!gameMap.containsKey(loc) && (loc.getX()!=startPosX && loc.getY()!=startPosY)) {
    			gameMap.put(loc, new Item(loc.getX(), loc.getY()));
    		} else {
    			i--;
    		}
    	}
    	
    	for(int i=0; i<10; i++) {
    		loc = new Location((int)(Math.random()*13), (int)(Math.random()*13));
    		if(!gameMap.containsKey(loc) && (loc.getX()!=startPosX && loc.getY()!=startPosY)) {
    			gameMap.put(loc, new Spike(loc.getX(), loc.getY()));
    		} else {
    			i--;
    		}
    	}
    	
    	out.reset();
		out.writeObject(game); 
		repaint();
	}

	public void countDown() {

		int count = 3;
		while(count != 0) {
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			};
			count--;
			countDown.setText(Integer.toString(count));
		}
		gameActive = true;

	}
}


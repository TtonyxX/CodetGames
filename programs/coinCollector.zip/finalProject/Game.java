import java.io.Serializable;
import java.util.Map;

public class Game implements Serializable {
	
	private Map<Location, Object> gameMap;
	private Player player;
	
	public Game(Map<Location, Object> gameMap, Player player) {
		this.gameMap = gameMap;
		this.player = player;
	}

	public Map<Location, Object> getGameMap() {
		return gameMap;
	}

	public void setGameMap(Map<Location, Object> gameMap) {
		this.gameMap = gameMap;
	}

	public Player getPlayer() {
		return player;
	}

	public void setPlayer(Player player) {
		this.player = player;
	}
	
}

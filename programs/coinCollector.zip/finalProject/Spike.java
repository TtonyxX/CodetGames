import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.awt.image.BufferedImage;

import javax.imageio.ImageIO;

public class Spike implements Serializable{

	private int x, y;
	
	public Spike(int x, int y) {
		this.x = x;
		this.y = y;
	}
	
	public void draw(Graphics g, int x, int y, BufferedImage icon) {
		
		Graphics2D g2 = (Graphics2D) g;
	    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		
		g2.setColor(Color.gray);
	    g2.drawImage(icon, x, y, null);
		
	}
	
	public Location getLocation() {
		return new Location(x, y);
	}
	
	public void setLocation(Location loc) {
		x = loc.getX();
		y = loc.getY();
	}
	
}

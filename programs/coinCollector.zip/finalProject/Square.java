import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;

public class Square {
	
	private int x, y;
	
	public Square(int x, int y) {
		this.x = x;
		this.y = y;
	}
	
	public void drawPlayer(Player player, Graphics g, String p) {
		if(!player.getMoved()) {
			if(p.equals("p1")) player.draw(g, x+5, y+5);
			else if(p.equals("p2")) player.draw(g, x+20, y+5);
		} else player.draw(g, x+15, y+5);
	}
	
	public void drawItem(Item item, Graphics g, BufferedImage icon) {
		item.draw(g, x+13, y+13, icon);
	}
	
	public void drawSpike(Spike spike, Graphics g, BufferedImage icon) {
		spike.draw(g, x, y, icon);
	}
	
	public void drawBomb(Bomb bomb, Graphics g, BufferedImage icon) {
		bomb.draw(g, x+10, y+5, icon);
	}
	
	public void draw(Graphics g) {
		g.setColor(Color.lightGray);
		g.fillRect(x, y, 50, 50);
		g.setColor(Color.BLACK);
		g.drawRect(x, y, 50, 50);
	}
	
	public int getX() {
		return x;
	}
	
	public int getY() {
		return y;
	}
	
}

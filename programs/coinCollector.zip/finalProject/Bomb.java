import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.io.Serializable;
import java.net.MalformedURLException;
import java.net.URL;
import java.awt.image.BufferedImage;

import javax.swing.ImageIcon;

public class Bomb implements Serializable {
	
	private int x, y;
	
	public Bomb() { }
	
	public void draw(Graphics g, int x, int y, BufferedImage icon) {
		
		Graphics2D g2 = (Graphics2D) g;
	    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		
		g2.setColor(Color.black);
		g.drawImage(icon, x, y, null);
		
	}
	
	public Location getLocation() {
		return new Location(x, y);
	}
	
	public void place(Location loc) {
		x = loc.getX();
		y = loc.getY();
	}

}

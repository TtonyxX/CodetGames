import java.io.IOException;

import javax.swing.JFrame;

public class Player2 {

	public static void main(String[] args) {
		
		JFrame frame = new JFrame("Client");
		 
        ClientScreen sc = new ClientScreen();
        frame.add(sc);
 
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
 
 		while(true) {
	        try {
	        	try {
					Thread.sleep(10);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				if(sc.shouldPoll()) {
					sc.poll();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}

}
